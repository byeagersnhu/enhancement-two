export const environment = {
    production: false,
    googleMapsApiKey: 'AIzaSyBz8I2E8DaZgSCQ6qL8tGK7a3_QeeNVhOo'
}